from . import cpu
from . import gpu
__all__=["cpu","gpu"]